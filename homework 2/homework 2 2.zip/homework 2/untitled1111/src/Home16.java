public class Home16 {
    public static void main(String[] args) {

        int a = 0;
        int b = 1;
        int c;
        System.out.print(a + " " + b + " ");
        for (int q = 2; q < 15; q++) {
            c = a + b;
            System.out.print(c + " ");
            a = b;
            b = c;

        }
        System.out.println();
    }
}
