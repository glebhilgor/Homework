public class Home8 {
    public static void main(String[] args) {
        int a = 10;
        double b = ((a / 100.0) * 10) + a;
        double c = ((b / 100.0) * 10) + b;
        double d = ((c / 100.0) * 10) + c;
        double e = ((d / 100.0) * 10) + d;
        double f = ((e / 100.0) * 10) + e;
        double g = ((f / 100.0) * 10) + f;
        System.out.println(a+b+c+d+e+f+g);
    }
}

