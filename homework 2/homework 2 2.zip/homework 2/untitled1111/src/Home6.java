public class Home6 {
    public static void main(String[] args) {

        int a = 5;
        int b = 6;
        if (a>b) {
            System.out.println(a);
        } else if (b>a) {
            System.out.println(b);
        }
    }
}
