public class Home11 {
    public static void main(String[] args) {

        int a = 8;
        int b = 7;
        int c;
        c = 0;
        for (int d = 0; d < b; d++) {
            c += a;
        }
        System.out.println(c);
    }
}
