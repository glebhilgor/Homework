public class Home2 {
    public static void main(String[] args) {

        int a = 9;
        int b = 5;
        int c = 5;
        if (a + b > c && a + c > b && b + c > a) {
            System.out.println("correct");
        } else {
            System.out.println("incorrect");
        }
    }
}
