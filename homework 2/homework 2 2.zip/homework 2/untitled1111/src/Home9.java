public class Home9 {
    public static void main(String[] args) {

        int a = 1;
        for (int b = 0; b < 24; b += 3) {
            a = a * 2;
            System.out.println(a);
        }


    }
}
