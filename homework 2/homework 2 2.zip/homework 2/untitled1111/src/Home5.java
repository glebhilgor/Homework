public class Home5 {
    public static void main(String[] args) {
        int a = -6;
        int b = 6;
        int c = -19;
        if (a > 0 && b > 0 && c > 0) {
            System.out.println("three positive numbers");
        } else if (a > 0 && b > 0 && c < 0) {
            System.out.println("two positive numbers, one negative");
        } else if (a > 0 && b < 0 && c > 0) {
            System.out.println("two positive numbers, one negative");
        } else if (a < 0 && b > 0 && c > 0) {
            System.out.println("two positive numbers, one negative");
        } else if (a > 0 && b < 0 && c < 0) {
            System.out.println("one positive number, two negatives");
        } else if (a < 0 && b > 0 && c < 0) {
            System.out.println("one positive number, two negatives");
        } else if (a < 0 && b < 0 && c > 0) {
            System.out.println("one positive number, two negatives");
        } else if (a < 0 && b < 0 && c < 0) {
            System.out.println("three negatives numbers");
        }
    }
}
