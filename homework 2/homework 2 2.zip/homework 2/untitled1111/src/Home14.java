public class Home14 {
    public static void main(String[] args) {

        int a = 0;
        for (int b = 1; b < 100; b = b + 2) {
            a += b;
        }
        System.out.println(a);
    }
}
