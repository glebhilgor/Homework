public class Hello {
    public static void main(String[] args) {
        double a = ((((3.0 / 3) * 3) + 3) / (((4 + 4) * 4) / 4));
        double b = (17.0 * 17 * 17) / ((4 + 16) * 20);
        double c = a + b;
        System.out.println(c);
        System.out.println("------------");


        int e = (3 * 3 * 3) + (4 * 4 * 4);
        int f = e * e * e * e;
        double g = ((1000.0 / 1) / 17);
        double h = (1.0 / 17);
        double t = 1.0 / h;
        double q = (t / f);
        double v = q * g;
        System.out.println(v);
        System.out.println("--------");




    }
}
