public class Home7 {
    public static void main(String[] args) {
        int a = 100;

        if (a == 1 || a == 21 || a == 31 || a == 41 || a == 51 || a == 61 || a == 71 || a == 81 || a == 91 || a == 101) {
            System.out.println("programmist " + a);
        } else if ((a > 1 && a < 5) || (a > 21 && a < 25) || (a > 31 && a < 35) || (a > 41 && a < 45) || (a > 51 && a < 55) || (a > 61 && a < 65) || (a > 71 && a < 75) || (a > 81 && a < 85) || (a > 91 && a < 95)) {
            System.out.println("programmista " + a);
        } else if ((a > 5 && a < 21) || (a >= 25 && a < 31) || (a >= 35 && a < 41) || (a >= 45 && a < 51) || (a >= 55 && a < 61) || (a >= 65 && a < 71) || (a >= 75 && a < 81) || (a >= 85 && a < 91) || (a >= 95 && a < 101)) {
            System.out.println("programmistov " + a);

        }
    }
}