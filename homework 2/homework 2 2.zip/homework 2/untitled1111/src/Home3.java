public class Home3 {
    public static void main(String[] args) {


        int a = -2;

        if (a>0) {
            System.out.println(a+1);
        } else if (a<0) {
            System.out.println(a-2);
        } else if (a==0) {
            System.out.println(10);
        }


    }
}
