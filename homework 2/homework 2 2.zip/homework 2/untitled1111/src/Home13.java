public class Home13 {
    public static void main(String[] args) {

        for (int a = 2; a < 101; a = a + 2) {
            System.out.println(a);
        }
    }
}