public class Home12 {
    public static void main(String[] args) {

        int c;
        double a = 2.54;
        for (int b = 1; b < 21; b++) {
            System.out.println(b*a);
        }

    }
}
