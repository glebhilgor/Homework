public class Home15 {
    public static void main(String[] args) {
        for (int b = 0; b < 3; b++) {
            for (int a = 0; a < 3; a++) {
                System.out.print("* ");
            }
            for (int c = 0; c < 2; c++) {
                System.out.print("* ");
            }
            for (int q = 0; q < 1; q++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}