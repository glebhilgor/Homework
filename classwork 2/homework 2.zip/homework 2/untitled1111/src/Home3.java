public class Home3 {
    public static void main(String[] args) {


    }
//        int a = 7;
//        int b = a > 0 ? (a + 1) : (a - 2);
//        if (b=0) {
//        System.out.println(b);


}

