public class Home6 {
    public static void main(String[] args) {


    }
}
