public class Home4 {
    public static void main(String[] args) {

        int a = -6;
        int b = -6;
        int c = -19;
        if (a > 0 && b > 0 && c > 0) {
            System.out.println("three positive numbers");
        } else if (a > 0 && b > 0 && c < 0) {
            System.out.println("two positive numbers");
        } else if (a > 0 && b < 0 && c > 0) {
            System.out.println("two positive numbers");
        } else if (a < 0 && b > 0 && c > 0) {
            System.out.println("two positive numbers");
        } else if (a > 0 && b < 0 && c < 0) {
            System.out.println("one positive number");
        } else if (a < 0 && b > 0 && c < 0) {
            System.out.println("one positive number");
        } else if (a < 0 && b < 0 && c > 0) {
            System.out.println("one positive number");
        }
    }
}